// Это комментарий в первой строке
#include <stdio.h>

int main() {
    printf("Hello, World!\n");
    return 0;
}

